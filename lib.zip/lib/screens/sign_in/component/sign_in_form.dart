import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:flutter_uiapp/component/custom_suffix.dart';
import 'package:flutter_uiapp/component/default_button.dart';
import 'package:flutter_uiapp/constant.dart';

class SignInForm extends StatefulWidget {
  const SignInForm({super.key});

  @override
  State<SignInForm> createState() => _SignInFormState();
}

class _SignInFormState extends State<SignInForm> {
  bool remember = false;
  @override
  Widget build(BuildContext context) {
    return Form(
              child: Column(
                children: [
                  emailFormField(),
                const SizedBox(
                    height: 30,
                  ),
                  passwordFormField(),
                 const SizedBox(
                    height: 30,
                  ),
                  rememberAndForgot(),
                  const SizedBox(
                    height: 20,
                  ),
                 const SizedBox(
                    height: 20,
                  ),
                  MyDefaultButton(text: "Sign In", press: () {})
                ],
              )
              );
  }

  Row rememberAndForgot() {
    return Row(
                children: [
                  Checkbox(value: remember, onChanged: (value){
                    setState(() {
                      remember = value!;
                    }
                    );
                  },
                  activeColor: kPrimaryColor,
                  ),
                 const Text("Remember Me"),
                  const Spacer(),
                 GestureDetector(
                  onTap: () {},
                  child: const Text("Forgot Password",
                  style: TextStyle(
                    decoration: TextDecoration.underline,
                  ),),
                 )
                ],
              );
  }

  TextFormField passwordFormField() {
    return TextFormField(
                onChanged: (value)  {},
                validator: (value) {},
                keyboardType: TextInputType.visiblePassword,
                decoration: const InputDecoration(
                  labelText: "Password",
                  hintText: "Enter Your Password",
                  contentPadding:  EdgeInsets.symmetric(
                    horizontal: 42,
                    vertical: 20,
                  ),
                  enabledBorder:  OutlineInputBorder(
                    borderRadius: BorderRadius.all(Radius.circular(28)),
                    borderSide: BorderSide(
                      color: kPrimaryColor
                    ),
                    gapPadding: 10,
                  ),
                  focusedBorder:  OutlineInputBorder(
                    borderRadius: BorderRadius.all(Radius.circular(28)),
                    borderSide: BorderSide(
                      color: kPrimaryColor
                    ),
                    gapPadding: 10,
                  ),
                  floatingLabelBehavior: FloatingLabelBehavior.always,
                  suffixIcon: CustomSuffix(
                    icon: "assets/icons/Mail.svg",
                  )
                ),
  );
  }

  TextFormField emailFormField() {
    return TextFormField(
                onChanged: (value)  {},
                validator: (value)  {},
                keyboardType: TextInputType.emailAddress,
                decoration: const InputDecoration(
                  labelText: "Email",
                  hintText: "Enter Your Email",
                  contentPadding:  EdgeInsets.symmetric(
                    horizontal: 42,
                    vertical: 20,
                  ),
                  enabledBorder:  OutlineInputBorder(
                    borderRadius: BorderRadius.all(Radius.circular(28)),
                    borderSide: BorderSide(
                      color: kPrimaryColor
                    ),
                    gapPadding: 10,
                  ),
                  focusedBorder:  OutlineInputBorder(
                    borderRadius: BorderRadius.all(Radius.circular(28)),
                    borderSide: BorderSide(
                      color: kPrimaryColor
                    ),
                    gapPadding: 10,
                  ),
                  floatingLabelBehavior: FloatingLabelBehavior.always,
                  suffixIcon: CustomSuffix(
                    icon: "assets/icons/Mail.svg",
                  )
                ),
  );
  }
}