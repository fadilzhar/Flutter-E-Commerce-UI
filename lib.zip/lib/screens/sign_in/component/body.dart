import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:flutter_uiapp/component/custom_suffix.dart';
import 'package:flutter_uiapp/component/default_button.dart';
import 'package:flutter_uiapp/constant.dart';
import 'package:flutter_uiapp/screens/sign_in/component/sign_in_form.dart';
import 'package:flutter_uiapp/size_config.dart';
import 'dart:core';

class Body extends StatefulWidget {
  const Body({super.key});

  @override
  State<Body> createState() => _BodyState();
}

class _BodyState extends State<Body> {
 bool remember = false;
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: SizedBox(
        width: double.infinity,
        child: Padding(
          padding: EdgeInsets.symmetric(horizontal: getPropScreenWidth(20)),
          child: Column(
            children: [
              const Text("Welcome Back",
              style: TextStyle(
                color: Colors.black,
                fontSize: 20,
                fontWeight: FontWeight.bold,
              ),
              ),
             const Text("Sign in with your Email and Password \n or continute with social media",
              textAlign: TextAlign.center,),
            SizedBox(
              height: SizeConfig.screenWidth * 0.06,
            ),
            SignInForm(),
            ],
          ),
        ),
      ),
    );
  }
}
